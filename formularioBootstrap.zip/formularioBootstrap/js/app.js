document.addEventListener('DOMContentLoaded', () => {
    const feedbackForm = document.getElementById('feedbackForm');
    const feedbacks = [];

    feedbackForm.addEventListener('submit', function (e) {
        e.preventDefault();

        const formData = {
            name: document.getElementById('name').value,
            registration: document.getElementById('registration').value,
            course: document.getElementById('course').value,
            teaching_plan: parseInt(document.getElementById('teaching_plan').value),
            teaching_method: parseInt(document.getElementById('teaching_method').value),
            labs_quality: parseInt(document.getElementById('labs_quality').value),
            points_distribution: parseInt(document.getElementById('points_distribution').value),
            course_coordination: parseInt(document.getElementById('course_coordination').value),
            suggestions: document.getElementById('suggestions').value
        };

        // salvar os feedbacks
        feedbacks.push(formData);
        alert('Feedback enviado com sucesso!');

        // atualizar as medias
        updateResults(feedbacks);
    });

    function updateResults(feedbacks) {
        const totalFeedbacks = feedbacks.length;

        // inicializar variaveis
        let totalTeachingPlan = 0;
        let totalTeachingMethod = 0;
        let totalLabsQuality = 0;
        let totalPointsDistribution = 0;
        let totalCourseCoordination = 0;

        feedbacks.forEach(feedback => {
            totalTeachingPlan += feedback.teaching_plan;
            totalTeachingMethod += feedback.teaching_method;
            totalLabsQuality += feedback.labs_quality;
            totalPointsDistribution += feedback.points_distribution;
            totalCourseCoordination += feedback.course_coordination;
        });

        // calcular medias
        const avgTeachingPlan = totalTeachingPlan / totalFeedbacks;
        const avgTeachingMethod = totalTeachingMethod / totalFeedbacks;
        const avgLabsQuality = totalLabsQuality / totalFeedbacks;
        const avgPointsDistribution = totalPointsDistribution / totalFeedbacks;
        const avgCourseCoordination = totalCourseCoordination / totalFeedbacks;

        // exibir resultados
        document.getElementById('avgTeachingPlan').textContent = avgTeachingPlan.toFixed(2);
        document.getElementById('avgTeachingMethod').textContent = avgTeachingMethod.toFixed(2);
        document.getElementById('avgLabsQuality').textContent = avgLabsQuality.toFixed(2);
        document.getElementById('avgPointsDistribution').textContent = avgPointsDistribution.toFixed(2);
        document.getElementById('avgCourseCoordination').textContent = avgCourseCoordination.toFixed(2);
    }
});
